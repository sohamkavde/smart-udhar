const mongoose = require("mongoose");

const GeneralSettingschema = new mongoose.Schema(
    {
        bussinessName: { type: String, trim: true },
        currencyFormate: { type: String, trim: true },
        timezone: { type: String, trim: true },
        language: { type: String, trim: true },
    }
);

module.exports = mongoose.model("GeneralSettings", GeneralSettingschema);